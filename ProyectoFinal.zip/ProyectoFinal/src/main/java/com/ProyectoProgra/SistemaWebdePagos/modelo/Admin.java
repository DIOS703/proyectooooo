/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ProyectoProgra.SistemaWebdePagos.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author zimme
 */
@Entity
@Table(name = "admin")
@NamedQueries({
    @NamedQuery(name = "Admin.findAll", query = "SELECT a FROM Admin a")})
public class Admin implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 50)
    @Column(name = "Usuario")
    private String usuario;
    @Size(max = 20)
    @Column(name = "contrasena")
    private String contrasena;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idADMIN")
    private Integer idADMIN;
    @JoinColumn(name = "EmpleadoidEmpleado", referencedColumnName = "idEmpleado")
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Empleado empleadoidEmpleado;

    public Admin() {
    }

    public Admin(Integer idADMIN) {
        this.idADMIN = idADMIN;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public Integer getIdADMIN() {
        return idADMIN;
    }

    public void setIdADMIN(Integer idADMIN) {
        this.idADMIN = idADMIN;
    }

    public Empleado getEmpleadoidEmpleado() {
        return empleadoidEmpleado;
    }

    public void setEmpleadoidEmpleado(Empleado empleadoidEmpleado) {
        this.empleadoidEmpleado = empleadoidEmpleado;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idADMIN != null ? idADMIN.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Admin)) {
            return false;
        }
        Admin other = (Admin) object;
        if ((this.idADMIN == null && other.idADMIN != null) || (this.idADMIN != null && !this.idADMIN.equals(other.idADMIN))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.ProyectoProgra.SistemaWebdePagos.modelo.Admin[ idADMIN=" + idADMIN + " ]";
    }
    
}
