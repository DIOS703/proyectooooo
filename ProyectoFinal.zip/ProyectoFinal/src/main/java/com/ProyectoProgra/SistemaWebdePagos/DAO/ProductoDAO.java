/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ProyectoProgra.SistemaWebdePagos.DAO;

import com.ProyectoProgra.SistemaWebdePagos.modelo.Producto;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author zimme
 */
public interface ProductoDAO extends CrudRepository<Producto, Integer> {

    @Override
    public List<Producto> findAll();
   
}
