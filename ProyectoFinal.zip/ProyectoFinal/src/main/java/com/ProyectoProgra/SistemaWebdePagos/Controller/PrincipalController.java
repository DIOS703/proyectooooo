/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ProyectoProgra.SistemaWebdePagos.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author zimme
 */
@Controller
public class PrincipalController {
    
    @RequestMapping("/url")
    public String page(Model model) {
        model.addAttribute("attribute", "value");
        return "view.name";
    }
        @GetMapping("/Clientes")
    public String abreClientes(){
        return "Clientes";
    }
            @GetMapping("/Empleados")
    public String abreEmpleados(){
        return "Empleados";
    }
            @GetMapping("/Ventas")
    public String abreventas(){
        return "Ventas";
    }
                @GetMapping("/Productos")
    public String abreproductos(){
        return "Productos";
    }
}
