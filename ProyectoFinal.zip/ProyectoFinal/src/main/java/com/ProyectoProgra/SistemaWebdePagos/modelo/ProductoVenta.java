/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ProyectoProgra.SistemaWebdePagos.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author zimme
 */
@Entity
@Table(name = "producto_venta")
@NamedQueries({
    @NamedQuery(name = "ProductoVenta.findAll", query = "SELECT p FROM ProductoVenta p")})
public class ProductoVenta implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ProductoVentaPK productoVentaPK;
    @Column(name = "cantidad")
    private Integer cantidad;
    @JoinColumn(name = "VentaidVenta", referencedColumnName = "idVenta", insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Venta venta;
    @JoinColumn(name = "ProductoidProducto", referencedColumnName = "idProducto", insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Producto producto;

    public ProductoVenta() {
    }

    public ProductoVenta(ProductoVentaPK productoVentaPK) {
        this.productoVentaPK = productoVentaPK;
    }

    public ProductoVenta(int productoidProducto, int ventaidVenta) {
        this.productoVentaPK = new ProductoVentaPK(productoidProducto, ventaidVenta);
    }

    public ProductoVentaPK getProductoVentaPK() {
        return productoVentaPK;
    }

    public void setProductoVentaPK(ProductoVentaPK productoVentaPK) {
        this.productoVentaPK = productoVentaPK;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (productoVentaPK != null ? productoVentaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductoVenta)) {
            return false;
        }
        ProductoVenta other = (ProductoVenta) object;
        if ((this.productoVentaPK == null && other.productoVentaPK != null) || (this.productoVentaPK != null && !this.productoVentaPK.equals(other.productoVentaPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.ProyectoProgra.SistemaWebdePagos.modelo.ProductoVenta[ productoVentaPK=" + productoVentaPK + " ]";
    }
    
}
