package com.ProyectoProgra.SistemaWebdePagos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaWebdePagosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaWebdePagosApplication.class, args);
	}

}
