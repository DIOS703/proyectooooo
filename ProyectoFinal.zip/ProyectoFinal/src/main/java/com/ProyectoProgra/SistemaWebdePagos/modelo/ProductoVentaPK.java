/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ProyectoProgra.SistemaWebdePagos.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author zimme
 */
@Embeddable
public class ProductoVentaPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "ProductoidProducto")
    private int productoidProducto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VentaidVenta")
    private int ventaidVenta;

    public ProductoVentaPK() {
    }

    public ProductoVentaPK(int productoidProducto, int ventaidVenta) {
        this.productoidProducto = productoidProducto;
        this.ventaidVenta = ventaidVenta;
    }

    public int getProductoidProducto() {
        return productoidProducto;
    }

    public void setProductoidProducto(int productoidProducto) {
        this.productoidProducto = productoidProducto;
    }

    public int getVentaidVenta() {
        return ventaidVenta;
    }

    public void setVentaidVenta(int ventaidVenta) {
        this.ventaidVenta = ventaidVenta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) productoidProducto;
        hash += (int) ventaidVenta;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductoVentaPK)) {
            return false;
        }
        ProductoVentaPK other = (ProductoVentaPK) object;
        if (this.productoidProducto != other.productoidProducto) {
            return false;
        }
        if (this.ventaidVenta != other.ventaidVenta) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.ProyectoProgra.SistemaWebdePagos.modelo.ProductoVentaPK[ productoidProducto=" + productoidProducto + ", ventaidVenta=" + ventaidVenta + " ]";
    }
    
}
